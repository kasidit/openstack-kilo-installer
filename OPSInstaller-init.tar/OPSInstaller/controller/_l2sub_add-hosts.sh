#!/bin/bash -x
#
# Openstack icehouse installation script on ubuntu 14.04
# by kasidit chanchio
# vasabilab, dept of computer science,
# Thammasat University, Thailand
#
# Copyright 2014  Kasidit Chanchio
#
#
# run below before launch this script
#printf "\nyou are supposed to be running ssh-agent at this point.\n"
# --->ssh-agent /bin/bash
# --> ssh-add
# copy Installer

cd $HOME/OPSInstaller/controller
pwd
cp /etc/hosts files/hosts.before_add_compute
#
echo "${2} ${1}" >> files/hosts
cp files/hosts /etc/hosts
