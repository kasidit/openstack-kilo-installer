# Openstack icehouse installation script on ubuntu 14.04 
# by kasidit chanchio
# vasabilab, dept of computer science, 
# Thammasat University, Thailand
#
# Copyright 2014  Kasidit Chanchio
#
# run with sudo or as root.
#
#!/bin/bash -x
cd $HOME/OPSInstaller/controller
pwd
#
echo "manual" > /etc/init/keystone.override
apt-get -y install keystone python-openstackclient apache2 libapache2-mod-wsgi memcached python-memcache
cp files/keystone.conf /etc/keystone/keystone.conf 
echo "su -s /bin/sh -c \"keystone-manage db_sync\" keystone"
su -s /bin/sh -c "keystone-manage db_sync" keystone
#
cp files/apache2.conf /etc/apache2/apache2.conf 
cp files/wsgi-keystone.conf /etc/apache2/sites-available/wsgi-keystone.conf

ln -s /etc/apache2/sites-available/wsgi-keystone.conf /etc/apache2/sites-enabled
mkdir -p /var/www/cgi-bin/keystone
#curl http://git.openstack.org/cgit/openstack/keystone/plain/httpd/keystone.py?h=stable/kilo \
#  | tee /var/www/cgi-bin/keystone/main /var/www/cgi-bin/keystone/admin
#wget http://localrepo/installer/keystone-py
wget http://vasabi-1234keystone-py-url4321-ibasav
cp keystone-py /var/www/cgi-bin/keystone/main
cp keystone-py /var/www/cgi-bin/keystone/admin
#
chown -R keystone:keystone /var/www/cgi-bin/keystone
chmod 755 /var/www/cgi-bin/keystone/*
service apache2 restart
rm -f /var/lib/keystone/keystone.db

#printf "add crontab to clear old credentials\n"
#
#(crontab -l -u keystone 2>&1 | grep -q token_flush) || \
#echo '@hourly /usr/bin/keystone-manage token_flush >/var/log/keystone/keystone-tokenflush.log 2>&1' >> /var/spool/cron/crontabs/keystone
