# Openstack icehouse installation script 
# on ubuntu 14.04 by kasidit chanchio
# vasabilab, dept of computer science, Thammasat University, Thailand
# copyright 2014 
#
#
#!/bin/bash -x
cd $HOME/OPSInstaller/controller
pwd
echo "Run this script as a user."
echo -n "1. create Identity service and endpoint...press"
read varkey

export OS_TOKEN=vasabilabADMIN_TOKEN
export OS_URL=http://controller:35357/v2.0

openstack service create \
  --name keystone --description "OpenStack Identity" identity
openstack endpoint create \
  --publicurl http://controller:5000/v2.0 \
  --internalurl http://controller:5000/v2.0 \
  --adminurl http://controller:35357/v2.0 \
  --region RegionOne \
  identity

echo -n "2. create Admin projects, users, and roles...press"
read varkey

openstack project create --description "Admin Project" admin

openstack user create --password vasabilabADMIN_PASS admin

openstack role create admin

openstack role add --project admin --user admin admin

printf "\n3. create Service project...press"
read varkey

openstack project create --description "Service Project" service

printf "\n4. create DEMO user/tenant/role...press"
read varkey

openstack project create --description "Demo Project" demo

openstack user create --password vasabilabDEMO_PASS demo

openstack role create user

openstack role add --project demo --user demo user

printf "\n5. Verify keystone Id Service...get a token by user id... press any key"
read varkey

sudo cp files/keystone-paste_stage10.ini /etc/keystone/keystone-paste.ini

unset OS_TOKEN OS_URL

openstack --os-auth-url http://controller:35357 \
  --os-project-name admin --os-username admin --os-auth-type password \
  --os-password vasabilabADMIN_PASS token issue

openstack --os-auth-url http://controller:35357 \
  --os-project-domain-id default --os-user-domain-id default \
  --os-project-name admin --os-username admin --os-auth-type password \
  --os-password vasabilabADMIN_PASS token issue

openstack --os-auth-url http://controller:35357 \
  --os-project-name admin --os-username admin --os-auth-type password \
  --os-password vasabilabADMIN_PASS project list

openstack --os-auth-url http://controller:35357 \
  --os-project-name admin --os-username admin --os-auth-type password \
  --os-password vasabilabADMIN_PASS user list

echo -n "next"
read varkey

openstack --os-auth-url http://controller:35357 \
  --os-project-name admin --os-username admin --os-auth-type password \
  --os-password vasabilabADMIN_PASS role list

openstack --os-auth-url http://controller:5000 \
  --os-project-domain-id default --os-user-domain-id default \
  --os-project-name demo --os-username demo --os-auth-type password \
  --os-password vasabilabDEMO_PASS token issue

openstack --os-auth-url http://controller:5000 \
  --os-project-domain-id default --os-user-domain-id default \
  --os-project-name demo --os-username demo --os-auth-type password \
  --os-password vasabilabDEMO_PASS user list
