# Openstack icehouse installation script on ubuntu 14.04 
# by kasidit chanchio
# vasabilab, dept of computer science, 
# Thammasat University, Thailand
#
# Copyright 2014  Kasidit Chanchio
#
#!/bin/bash -x
#
case $1 in 
	0) sudo /bin/bash -x ./exe-stage00-SUDO-update.sh 2>&1 | tee log/s00.log; \
		printf "\nnext: ./exe-run-verbose.sh 1\n" ;;
	1) sudo ./exe-stage01-SUDO-preinstall.sh | tee log/s01.log ; \
		printf "\nnext, on network node: cd OPSInstaller/network; ./exe-run-verbose.sh 0\n" ;; 
	4) sudo /bin/bash -x ./exe-stage04-SUDO-mysql.sh | tee log/s04.log ; \
		printf "\nnext, on network node: cd OPSInstaller/network; ./exe-run-verbose.sh 5\n" ;;
	7) sudo /bin/bash -x ./exe-stage07-SUDO-rabbit.sh 2>&1 | tee log/s07.log ;\
		printf "\nnext: ./exe-run-verbose.sh 8\n" ;;
	8) /bin/bash -x ./exe-stage08-USER-keystone-database.sh 2>&1 | tee log/s08.log ; \
		printf "\nnext: ./exe-run-verbose.sh 9\n" ;;
	9) sudo /bin/bash -x ./exe-stage09-SUDO-keystone.sh 2>&1 | tee log/s09.log ;\
		printf "\nnext: ./exe-run-verbose.sh 10\n" ;;
	10) /bin/bash -x ./exe-stage10-USER-service-endpoints.sh 2>&1 | tee log/s10.log ;\
		printf "\nnext: ./exe-run-verbose.sh 11\n" ;;
	11) /bin/bash -x ./exe-stage11-USER-test-envscript.sh 2>&1 | tee log/s11.log ; \
		printf "\nnext: ./exe-run-verbose.sh 12\n" ;;
	12) /bin/bash -x ./exe-stage12-USER-glance-database.sh 2>&1 | tee log/s12.log ;\
		printf "\nnext: ./exe-run-verbose.sh 13\n" ;;
	13) /bin/bash -x ./exe-stage13-USER-glance-endpoints.sh 2>&1 | tee log/s13.log ;\
		printf "\nnext: ./exe-run-verbose.sh 14\n" ;;
	14) sudo /bin/bash -x ./exe-stage14-SUDO-glance.sh 2>&1 | tee log/s14.log ;\
		printf "\nnext: ./exe-run-verbose.sh 15\n" ;;
	15) /bin/bash -x ./exe-stage15-USER-verify-glance.sh 2>&1 | tee log/s15.log ;\
		printf "\nnext: ./exe-run-verbose.sh 16\n"  ;;
	16) /bin/bash -x ./exe-stage16-USER-nova-database.sh 2>&1 | tee log/s16.log ; \
		printf "\nnext: ./exe-run-verbose.sh 17\n" ;;
	17) /bin/bash -x ./exe-stage17-USER-nova-endpoints.sh 2>&1 | tee log/s17.log ; \
		printf "\nnext: ./exe-run-verbose.sh 18\n" ;;
	18) sudo /bin/bash -x ./exe-stage18-SUDO-nova.sh 2>&1 | tee log/s18.log ; \
		printf "\nnext on compute: cd OPSInstaller/compute ; ./exe-run-verbose.sh 19\n" ;;
	20) /bin/bash -x ./exe-stage20-USER-verify-nova.sh 2>&1 | tee log/s20.log ; \
		printf "\nnext: ./exe-run-verbose.sh 21\n" ;;
	21) /bin/bash -x ./exe-stage21-USER-neutron-database.sh 2>&1 | tee log/s21.log ; \
		printf "\nnext: ./exe-run-verbose.sh 22\n" ;;
	22) /bin/bash -x ./exe-stage22-USER-neutron-endpoints.sh 2>&1 | tee log/s22.log ; \
		printf "\nnext: ./exe-run-verbose.sh 23\n" ;;
	23) sudo /bin/bash -x ./exe-stage23-SUDO-neutron.sh 2>&1 | tee log/s23.log ; \
		printf "\nnext: ./exe-run-verbose.sh 24 \n" ;;
	24) /bin/bash -x ./exe-stage24-USER-verify-neutron.sh 2>&1 | tee log/s24.log ; \
		printf "\nnext on network: cd OPSInstaller/network ; ./exe-run-verbose.sh 25\n" ;;
	26) sudo /bin/bash -x ./exe-stage26-SUDO-reconfig-neutron-nova.sh 2>&1 | tee log/s26.log ; \
		printf "\nnext on network: cd OPSInstaller/network ; ./exe-run-verbose.sh 27\n" ;;
	28) /bin/bash -x ./exe-stage28-USER-verify-neutron2.sh 2>&1 | tee log/s28.log ; \
		printf "\nnext on compute: cd OPSInstaller/compute ; ./exe-run-verbose.sh 29\n" ;;
	30) /bin/bash -x ./exe-stage30-USER-verify-neutron3.sh 2>&1 | tee log/s30.log ; \
		printf "\nnext: ./exe-run-verbose.sh 31\n" ;;
	31) /bin/bash -x ./exe-stage31-USER-initial-network.sh 2>&1 | tee log/s31.log ; \
		printf "\nnext: ./exe-run-verbose.sh 32\n" ;;
	32) sudo /bin/bash -x ./exe-stage32-SUDO-horizon.sh 2>&1 | tee log/s32.log ; \
		printf "\nnext: that's it for now...\n" ;;
	*) printf "\ninvalid parameter value!\n" ;;
esac
