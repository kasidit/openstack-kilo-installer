# Openstack icehouse installation script on ubuntu 14.04 
# by kasidit chanchio
# vasabilab, dept of computer science, 
# Thammasat University, Thailand
#
# Copyright 2014  Kasidit Chanchio
#
# Run this with sudo or as root

#!/bin/bash -x
cd $HOME/OPSInstaller/controller
pwd
#
printf "Check ntp\n"
for count1 in 1 2 3 4 5 6
do
    syspeerflag=$(ntpq -c assoc | grep sys.peer | wc -l)
    if [ "${syspeerflag}" = "0" ]; then
       echo "trial $count1"
       if [ "${count1}" = "10" ]; then
          echo "WARNING: Still cannot sync. Continue anyway!" 
          break
       fi
       echo "wait 10s more"
       sleep 10
    else
       echo "ntp sync is ok"
       break
    fi
done
ntpq -c peers
ntpq -c assoc
#
printf "\nNext... \n\n" 
#read varkey
#
#clear
#printf "Next mysql installation will ask you to enter root password \n" 
#printf "that you defined previously in the install-paramrc.sh file.\n" 
#printf "IT IS IMPORTANT THAT YOU ENTER THIS PASSWORD CORRECTLY! \nThe password is.." 
#
#echo vasabilabMYSQL_PASS
#
#printf "\nplease enter the password above... \n\n" 
##read varkey
#
#while [ "$varkey" != "vasabilabMYSQL_PASS" ] 
#do

#  printf "\nNot match! please enter the password again... \n\n" 
#  #read varkey
#
#done
#
apt-get -y install debconf-utils

debconf-set-selections <<< 'mariadb-server-5.5 mysql-server/root_password password vasabilabMYSQL_PASS' 
debconf-set-selections <<< 'mariadb-server-5.5 mysql-server/root_password_again password vasabilabMYSQL_PASS' 
apt-get -y install mariadb-server
apt-get -y install python-mysqldb
#
printf "1. set my.cnf configuration... press any key\n" 
#read varkey

cp files/mysqld_openstack.cnf /etc/mysql/conf.d/mysqld_openstack.cnf

printf "3. restart mysql & delete anonymous acct... press\n"
#read varkey

service mysql restart
#mysql_secure_installation
mysql -u root -pvasabilabMYSQL_PASS -e "UPDATE mysql.user SET Password=PASSWORD('vasabilabMYSQL_PASS') WHERE User='root';"
mysql -u root -pvasabilabMYSQL_PASS -e "DELETE FROM mysql.user WHERE User='root' AND Host NOT IN ('localhost', '127.0.0.1', '::1');"
mysql -u root -pvasabilabMYSQL_PASS -e "DELETE FROM mysql.user WHERE User='';"
mysql -u root -pvasabilabMYSQL_PASS -e "DELETE FROM mysql.db WHERE Db='test' OR Db='test\_%';"
mysql -u root -pvasabilabMYSQL_PASS -e "FLUSH PRIVILEGES;"
#
exit 0
# set max connection error of mysql to a high value
#
#export MYSQL_PASS=vasabilabMYSQL_PASS
#mysql -u root -pvasabilabMYSQL_PASS -e "SET GLOBAL max_connect_errors=10000;"
