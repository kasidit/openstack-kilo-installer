# Openstack icehouse installation script on ubuntu 14.04 
# by kasidit chanchio
# vasabilab, dept of computer science, 
# Thammasat University, Thailand
#
# Copyright 2014  Kasidit Chanchio
#
#!/bin/bash -x
#
cd $HOME/OPSInstaller/controller
pwd
printf "1. set interface/hosts files... press any key\n"
read varkey

cp files/interfaces /etc/network/interfaces
cp files/hosts /etc/hosts

printf "2. set ntp server \npress any key.."
read varkey
apt-get -y install ntp
cp files/ntp.conf /etc/ntp.conf
rm /var/lib/ntp/ntp.conf.dhcp

ifdown vasabi-1234controller_ip_nic4321-ibasav
ifup vasabi-1234controller_ip_nic4321-ibasav
service ntp restart
sleep 5
# restore later 
#cp /etc/sudoers files/sudoers.save
#echo "vasabi ALL=NOPASSWD: ALL" >> /etc/sudoers
#
# test connectivity
ifconfig
#ping -c 4 network
#ping -c 4 compute
