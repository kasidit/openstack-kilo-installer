
# Openstack kilo installation script on ubuntu 14.04 
# by kasidit chanchio
# vasabilab, dept of computer science, 
# Thammasat University, Thailand
#
# Copyright 2015  Kasidit Chanchio
#
#!/bin/bash -x
#
# mysql
ssh -t vasabi-1234loginname4321-ibasav@controller sudo /bin/bash -x ./OPSInstaller/controller/exe-stage04-SUDO-mysql.sh | tee log/s04-controller.log
ssh -t vasabi-1234loginname4321-ibasav@network sudo /bin/bash -x ./OPSInstaller/network/exe-stage05-SUDO-network-mysql.sh | tee log/s05-network.log
ssh -t vasabi-1234loginname4321-ibasav@compute sudo /bin/bash -x ./OPSInstaller/compute/exe-stage06-SUDO-compute-mysql.sh | tee log/s06-compute.log
printf "\nnext run ./OS-installer-03-rabbitmq.sh\n"
