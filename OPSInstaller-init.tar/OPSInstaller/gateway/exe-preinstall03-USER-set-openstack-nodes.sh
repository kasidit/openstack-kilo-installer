#!/bin/bash -x 
#
# Openstack icehouse installation script on ubuntu 14.04 
# by kasidit chanchio
# vasabilab, dept of computer science, 
# Thammasat University, Thailand
#
# Copyright 2014  Kasidit Chanchio
#
#
# run below before launch this script
#printf "\nyou are supposed to be running ssh-agent at this point.\n"
# --->ssh-agent /bin/bash
# --> ssh-add
# copy Installer 

#cd $HOME/OPSInstaller/gateway
pwd
#ssh -t vasabi-1234loginname4321-ibasav@network sudo timedatectl set-timezone Asia/Bangkok
# time zone should be one of vasabi parametert
#ssh -t vasabi-1234loginname4321-ibasav@network sudo date --set=\"$(date)\"

echo "copy installer to nodes.. press"
#read varkey
scp OPSInstaller.tar vasabi-1234loginname4321-ibasav@controller:/home/vasabi-1234loginname4321-ibasav/OPSInstaller.tar
scp OPSInstaller.tar vasabi-1234loginname4321-ibasav@network:/home/vasabi-1234loginname4321-ibasav/OPSInstaller.tar
scp OPSInstaller.tar vasabi-1234loginname4321-ibasav@compute:/home/vasabi-1234loginname4321-ibasav/OPSInstaller.tar
#
echo "extract installer files on controller.. press"
#read varkey
ssh vasabi-1234loginname4321-ibasav@controller tar xvf /home/vasabi-1234loginname4321-ibasav/OPSInstaller.tar | tee log/extract-controller-current.log
echo "extract installer files on network node.. press"
#read varkey
ssh vasabi-1234loginname4321-ibasav@network tar xvf /home/vasabi-1234loginname4321-ibasav/OPSInstaller.tar | tee log/extract-network-current.log
echo "extract installer files on compute node.. press"
#read varkey
ssh vasabi-1234loginname4321-ibasav@compute tar xvf /home/vasabi-1234loginname4321-ibasav/OPSInstaller.tar | tee log/extract-compute-current.log
#

