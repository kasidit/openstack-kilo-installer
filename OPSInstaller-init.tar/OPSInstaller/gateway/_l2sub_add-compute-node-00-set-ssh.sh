# Openstack icehouse installation script on ubuntu 14.04 
# by kasidit chanchio
# vasabilab, dept of computer science, 
# Thammasat University, Thailand
#
# Copyright 2014  Kasidit Chanchio
# arg1 = IP address
#!/bin/bash -x 
#
echo "accept host keys"
# delete hashed host key
ssh-keygen -R ${1}
./expectsshyesno.sh vasabi-1234loginname4321-ibasav ${1}

echo "propagate credentials"
sshpass -pvasabi-1234loginpassword4321-ibasav scp /home/vasabi-1234loginname4321-ibasav/.ssh/id_rsa.pub vasabi-1234loginname4321-ibasav@${1}:/home/vasabi-1234loginname4321-ibasav/authorized_keys

sshpass -pvasabi-1234loginpassword4321-ibasav ssh  vasabi-1234loginname4321-ibasav@${1} "(mkdir /home/vasabi-1234loginname4321-ibasav/.ssh; mv /home/vasabi-1234loginname4321-ibasav/authorized_keys /home/vasabi-1234loginname4321-ibasav/.ssh/authorized_keys)"

echo "check date time of ${1}"
ssh  vasabi-1234loginname4321-ibasav@${1} date

echo "set sudoers"
sshpass -pvasabi-1234loginpassword4321-ibasav scp files/adjustsudoer.sh vasabi-1234loginname4321-ibasav@${1}:/home/vasabi-1234loginname4321-ibasav/adjustsudoer.sh

./expectsetsudoer.sh vasabi-1234loginname4321-ibasav ${1} vasabi-1234loginpassword4321-ibasav

echo "set timezone of controller network compute"
ssh -t vasabi-1234loginname4321-ibasav@${1} sudo timedatectl set-timezone vasabi-1234timezone4321-ibasav

echo "set date of controller network compute"
ssh -t vasabi-1234loginname4321-ibasav@${1} sudo date --set=\"$(date)\"
