time /bin/bash ./XOS-batch-installer-00-to-09.sh | tee ./OS-remote-install-results.txt
