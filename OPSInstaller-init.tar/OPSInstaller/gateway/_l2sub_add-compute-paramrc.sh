#!/bin/bash 
#
# OpenStack Installation script (parameter definition)
#
# copyright 2014 kasidit chanchio, vasabilab 
# http://vasabilab.cs.tu.ac.th
# Department of Computer Science, 
# Faculty of Science and Technology, Thammasat University
#
#
export NEW_COMPUTE_NAME=vasabi-1234new_compute_node_name4321-ibasav
export NEW_COMPUTE_IP=vasabi-1234new_compute_ip4321-ibasav
export NEW_COMPUTE_IP_NIC=vasabi-1234new_compute_ip_nic4321-ibasav
export NEW_DATA_TUNNEL_COMPUTE_NODE_IP=vasabi-1234new_compute_node_data_tunnel_ip4321-ibasav
export NEW_DATA_TUNNEL_COMPUTE_NODE_IP_NIC=vasabi-1234new_compute_node_data_tunnel_ip_nic4321-ibasav
#
export NEW_COMPUTE_CONTROLLER_NODE_IP=vasabi-1234new_compute_controller_node_ip4321-ibasav
export NEW_COMPUTE_NETWORK_NODE_IP=vasabi-1234new_compute_network_node_ip4321-ibasav
