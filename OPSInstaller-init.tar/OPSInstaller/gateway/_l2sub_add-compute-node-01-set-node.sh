#!/bin/bash -x 
#
# Openstack icehouse installation script on ubuntu 14.04 
# by kasidit chanchio
# vasabilab, dept of computer science, 
# Thammasat University, Thailand
#
# Copyright 2014  Kasidit Chanchio
#
# arg1 = hostname arg2 = IP address 

#cd $HOME/OPSInstaller/gateway
pwd
echo "adjusting host files.. press"
cp /etc/hosts files/hosts.before_add_compute-${2}
echo "${2} ${1}" >> files/hosts
sudo cp files/hosts /etc/hosts
#
ssh -t vasabi-1234loginname4321-ibasav@controller sudo /home/vasabi-1234loginname4321-ibasav/OPSInstaller/controller/_l2sub_add-hosts.sh ${1} ${2}
ssh -t vasabi-1234loginname4321-ibasav@network sudo /home/vasabi-1234loginname4321-ibasav/OPSInstaller/network/_l2sub_add-hosts.sh ${1} ${2}
#
echo "copy installer to nodes.. press"
#
cd ../..
pwd
tar cvf OPSInstaller-${2}.tar OPSInstaller-${2}
#
scp OPSInstaller-${2}.tar vasabi-1234loginname4321-ibasav@${2}:/home/vasabi-1234loginname4321-ibasav/OPSInstaller-${2}.tar
#
echo "extract installer files on new compute node.. press"
#read varkey
ssh vasabi-1234loginname4321-ibasav@${2} tar xvf /home/vasabi-1234loginname4321-ibasav/OPSInstaller-${2}.tar | tee log/extract-newcompute-current.log
