# Openstack icehouse installation script on ubuntu 14.04 
# by kasidit chanchio
# vasabilab, dept of computer science, 
# Thammasat University, Thailand
#
# Copyright 2014  Kasidit Chanchio
#
#!/bin/bash -x 
#
ssh-keygen -t rsa
scp /home/vasabi-1234loginname4321-ibasav/.ssh/id_rsa.pub vasabi-1234loginname4321-ibasav@controller:/home/vasabi-1234loginname4321-ibasav/authorized_keys
scp /home/vasabi-1234loginname4321-ibasav/.ssh/id_rsa.pub vasabi-1234loginname4321-ibasav@network:/home/vasabi-1234loginname4321-ibasav/authorized_keys
scp /home/vasabi-1234loginname4321-ibasav/.ssh/id_rsa.pub vasabi-1234loginname4321-ibasav@compute:/home/vasabi-1234loginname4321-ibasav/authorized_keys

ssh  vasabi-1234loginname4321-ibasav@controller "(mkdir /home/vasabi-1234loginname4321-ibasav/.ssh; mv /home/vasabi-1234loginname4321-ibasav/authorized_keys /home/vasabi-1234loginname4321-ibasav/.ssh/authorized_keys)"
ssh  vasabi-1234loginname4321-ibasav@network "(mkdir /home/vasabi-1234loginname4321-ibasav/.ssh; mv /home/vasabi-1234loginname4321-ibasav/authorized_keys /home/vasabi-1234loginname4321-ibasav/.ssh/authorized_keys)"
ssh  vasabi-1234loginname4321-ibasav@compute "(mkdir /home/vasabi-1234loginname4321-ibasav/.ssh; mv /home/vasabi-1234loginname4321-ibasav/authorized_keys /home/vasabi-1234loginname4321-ibasav/.ssh/authorized_keys)"

echo "Next, you may run\n   ssh-agent /bin/bash\n   ssh-add\nand run next openstak install script"
