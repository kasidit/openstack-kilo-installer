# Openstack kilo installation script on ubuntu 14.04 
# by kasidit chanchio
# vasabilab, dept of computer science, 
# Thammasat University, Thailand
#
# Copyright 2015  Kasidit Chanchio
#
#!/bin/bash -x
#
# node setups
ssh -t vasabi-1234loginname4321-ibasav@controller sudo /bin/bash -x ./OPSInstaller/controller/exe-stage00-SUDO-update.sh | tee log/s00-controller.log
ssh -t vasabi-1234loginname4321-ibasav@controller sudo /bin/bash -x ./OPSInstaller/controller/exe-stage01-SUDO-preinstall.sh | tee log/s01-controller.log
ssh -t vasabi-1234loginname4321-ibasav@network sudo /bin/bash -x ./OPSInstaller/network/exe-stage00-SUDO-update.sh | tee log/s00-network.log
ssh -t vasabi-1234loginname4321-ibasav@network sudo /bin/bash -x ./OPSInstaller/network/exe-stage02-SUDO-network-preinstall.sh | tee log/s02-network.log
ssh -t vasabi-1234loginname4321-ibasav@compute sudo /bin/bash -x ./OPSInstaller/compute/exe-stage00-SUDO-update.sh | tee log/s00-compute.log
ssh -t vasabi-1234loginname4321-ibasav@compute sudo /bin/bash -x ./OPSInstaller/compute/exe-stage03-SUDO-compute-preinstall.sh | tee log/s03-compute.log
printf "\nnext run ./OS-installer-02-mysql.sh \n"
