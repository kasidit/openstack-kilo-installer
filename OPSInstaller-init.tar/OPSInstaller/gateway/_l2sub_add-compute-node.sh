# Openstack kilo installation script on ubuntu 14.04 
# by kasidit chanchio
# vasabilab, dept of computer science, 
# Thammasat University, Thailand
#
# Copyright 2015  Kasidit Chanchio
#
# Note:
# Before this, config the IP stuffs for the node and change .paramrc.sh 
# then do the ./exe-config... and cd OPSI.../gateway and call this script
#
#!/bin/bash -x
#
# Do the following when adding a new node. 
#   - add new IP numbers of the two networks of the new compute node
#     in the install-paramrc.sh 
#   - run ./exe-config-...
#   - cd to OPSInstaller/gateway this directory and run this script.
#    
#
. ./_l2sub_add-compute-paramrc.sh
#
export ORI_COMPUTE_IP=vasabi-1234gen_compute_ip4321-ibasav
export ORI_COMPUTE_IP_NIC=vasabi-1234gen_compute_ip_nic4321-ibasav
export ORI_DATA_TUNNEL_COMPUTE_NODE_IP=vasabi-1234gen_data_tunnel_compute_node_ip4321-ibasav
export ORI_DATA_TUNNEL_COMPUTE_NODE_IP_NIC=vasabi-1234gen_data_tunnel_compute_node_ip_nic4321-ibasav
#
rm -rf ../../OPSInstaller-${NEW_COMPUTE_IP}
mkdir ../../OPSInstaller-${NEW_COMPUTE_IP}
cp -R ../compute.generic ../../OPSInstaller-${NEW_COMPUTE_IP}/compute-${NEW_COMPUTE_IP}
#
# Script to define parameter values below
#
TARGET_LOCATION=../../OPSInstaller-${NEW_COMPUTE_IP}/compute-${NEW_COMPUTE_IP}
ETC_FILES=${TARGET_LOCATION}/files/*
SCRIPT_FILES=${TARGET_LOCATION}/*.sh
#
# Change  NEW_COMPUTE_IP
#
printf "\n---etc files---\n"
grep -n "${ORI_COMPUTE_IP}" ${ETC_FILES} | tee ./tmpfile ; wc -l ./tmpfile
sed -i "s/${ORI_COMPUTE_IP}/${NEW_COMPUTE_IP}/g" ${ETC_FILES}
grep -n "${NEW_COMPUTE_IP}" ${ETC_FILES}  | tee ./tmpfile ; wc -l ./tmpfile 
#
printf "\n---script---\n"
grep -n "${ORI_COMPUTE_IP}" ${SCRIPT_FILES} | tee ./tmpfile ; wc -l ./tmpfile
sed -i "s/${ORI_COMPUTE_IP}/${NEW_COMPUTE_IP}/g" ${SCRIPT_FILES}
grep -n "${NEW_COMPUTE_IP}" ${SCRIPT_FILES}  | tee ./tmpfile ; wc -l ./tmpfile 
#
# Change  NEW_COMPUTE_IP_NIC
#
printf "\n---etc files---\n"
grep -n "${ORI_COMPUTE_IP_NIC}" ${ETC_FILES} | tee ./tmpfile ; wc -l ./tmpfile
sed -i "s/${ORI_COMPUTE_IP_NIC}/${NEW_COMPUTE_IP_NIC}/g" ${ETC_FILES}
grep -n "${NEW_COMPUTE_IP_NIC}" ${ETC_FILES}  | tee ./tmpfile ; wc -l ./tmpfile 
#
printf "\n---script---\n"
grep -n "${ORI_COMPUTE_IP_NIC}" ${SCRIPT_FILES} | tee ./tmpfile ; wc -l ./tmpfile
sed -i "s/${ORI_COMPUTE_IP_NIC}/${NEW_COMPUTE_IP_NIC}/g" ${SCRIPT_FILES}
grep -n "${NEW_COMPUTE_IP_NIC}" ${SCRIPT_FILES}  | tee ./tmpfile ; wc -l ./tmpfile 
#
# Change  NEW_DATA_TUNNEL_COMPUTE_NODE_IP
#
printf "\n---etc files---\n"
grep -n "${ORI_DATA_TUNNEL_COMPUTE_NODE_IP}" ${ETC_FILES} | tee ./tmpfile ; wc -l ./tmpfile
sed -i "s/${ORI_DATA_TUNNEL_COMPUTE_NODE_IP}/${NEW_DATA_TUNNEL_COMPUTE_NODE_IP}/g" ${ETC_FILES}
grep -n "${NEW_DATA_TUNNEL_COMPUTE_NODE_IP}" ${ETC_FILES}  | tee ./tmpfile ; wc -l ./tmpfile 
#
printf "\n---script---\n"
grep -n "${ORI_DATA_TUNNEL_COMPUTE_NODE_IP}" ${SCRIPT_FILES} | tee ./tmpfile ; wc -l ./tmpfile
sed -i "s/${ORI_DATA_TUNNEL_COMPUTE_NODE_IP}/${NEW_DATA_TUNNEL_COMPUTE_NODE_IP}/g" ${SCRIPT_FILES}
grep -n "${NEW_DATA_TUNNEL_COMPUTE_NODE_IP}" ${SCRIPT_FILES}  | tee ./tmpfile ; wc -l ./tmpfile 
#
# Change  NEW_DATA_TUNNEL_COMPUTE_NODE_IP_NIC
#
printf "\n---etc files---\n"
grep -n "${ORI_DATA_TUNNEL_COMPUTE_NODE_IP_NIC}" ${ETC_FILES} | tee ./tmpfile ; wc -l ./tmpfile
sed -i "s/${ORI_DATA_TUNNEL_COMPUTE_NODE_IP_NIC}/${NEW_DATA_TUNNEL_COMPUTE_NODE_IP_NIC}/g" ${ETC_FILES}
grep -n "${NEW_DATA_TUNNEL_COMPUTE_NODE_IP_NIC}" ${ETC_FILES}  | tee ./tmpfile ; wc -l ./tmpfile 
#
printf "\n---script---\n"
grep -n "${ORI_DATA_TUNNEL_COMPUTE_NODE_IP_NIC}" ${SCRIPT_FILES} | tee ./tmpfile ; wc -l ./tmpfile
sed -i "s/${ORI_DATA_TUNNEL_COMPUTE_NODE_IP_NIC}/${NEW_DATA_TUNNEL_COMPUTE_NODE_IP_NIC}/g" ${SCRIPT_FILES}
grep -n "${NEW_DATA_TUNNEL_COMPUTE_NODE_IP_NIC}" ${SCRIPT_FILES}  | tee ./tmpfile ; wc -l ./tmpfile 
#
# setup gateway  
#
/bin/bash -x _l2sub_add-compute-node-00-set-ssh.sh ${NEW_COMPUTE_IP} | tee log/s00-newcompute.log
/bin/bash -x _l2sub_add-compute-node-01-set-node.sh ${NEW_COMPUTE_NAME} ${NEW_COMPUTE_IP} | tee log/s01-newcompute.log
#
ssh -t vasabi-1234loginname4321-ibasav@${NEW_COMPUTE_IP} sudo /bin/bash -x ./OPSInstaller-${NEW_COMPUTE_IP}/compute-${NEW_COMPUTE_IP}/define-controller-network-hosts.sh ${NEW_COMPUTE_IP} ${NEW_COMPUTE_NAME} ${NEW_COMPUTE_CONTROLLER_NODE_IP} ${NEW_COMPUTE_NETWORK_NODE_IP} | tee log/s00-definehosts.log
#
ssh -t vasabi-1234loginname4321-ibasav@${NEW_COMPUTE_IP} mv ./OPSInstaller-${NEW_COMPUTE_IP} ./OPSInstaller
ssh -t vasabi-1234loginname4321-ibasav@${NEW_COMPUTE_IP} mv ./OPSInstaller/compute-${NEW_COMPUTE_IP} ./OPSInstaller/compute
#
# node setups
ssh -t vasabi-1234loginname4321-ibasav@${NEW_COMPUTE_IP} sudo /bin/bash -x ./OPSInstaller/compute/exe-stage00-SUDO-update.sh | tee log/s00-compute.log
ssh -t vasabi-1234loginname4321-ibasav@${NEW_COMPUTE_IP} sudo /bin/bash -x ./OPSInstaller/compute/exe-stage03-SUDO-compute-preinstall.sh | tee log/s03-compute.log
#
# mysql
ssh -t vasabi-1234loginname4321-ibasav@${NEW_COMPUTE_IP} sudo /bin/bash -x ./OPSInstaller/compute/exe-stage06-SUDO-compute-mysql.sh | tee log/s06-compute.log
#
# nova 
ssh -t vasabi-1234loginname4321-ibasav@${NEW_COMPUTE_IP} sudo /bin/bash -x ./OPSInstaller/compute/exe-stage19-SUDO-nova-compute.sh | tee log/s19-compute.log
#
# neutron
ssh -t vasabi-1234loginname4321-ibasav@${NEW_COMPUTE_IP} sudo /bin/bash -x ./OPSInstaller/compute/exe-stage29-SUDO-compute-neutron.sh | tee log/s29-compute.log
#
ssh -t vasabi-1234loginname4321-ibasav@network sudo /bin/bash -x ./OPSInstaller/network/restart-all-neutron-services.sh | tee log/s29-restart-compute.log
printf "\nDone!\n"
