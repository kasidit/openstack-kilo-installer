# Openstack icehouse installation script on ubuntu 14.04 
# by kasidit chanchio
# vasabilab, dept of computer science, 
# Thammasat University, Thailand
#
# Copyright 2014  Kasidit Chanchio
#
# this script or commands below must ba called
# prior to openstack installation
#
#!/bin/bash 
#
cd $HOME/OPSInstaller/network
pwd
#
cp files/hosts /etc/hosts
cp /etc/apt/sources.list /etc/apt/sources.list.saved
cp files/local-sources.list /etc/apt/sources.list
# 
printf "set repo and update\n"
apt-get update
apt-get -y install ubuntu-keyring
#apt-get -y dist-upgrade
#
printf "next"
#read varkey
#
apt-get install ubuntu-cloud-keyring
#
#echo "deb http://localrepo/ubuntu" \
#  "trusty-updates/kilo main" > /etc/apt/sources.list.d/cloudarchive-kilo.list
#echo "deb http://localcloudrepo/ubuntu" \
#  "trusty-updates/kilo main" > /etc/apt/sources.list.d/cloudarchive-kilo.list
#
echo "deb http://localcloudrepo/vasabi-1234localcloudrepodir4321-ibasav" \
  "trusty-updates/kilo main" > /etc/apt/sources.list.d/cloudarchive-kilo.list
apt-get update
#apt-get -y dist-upgrade
