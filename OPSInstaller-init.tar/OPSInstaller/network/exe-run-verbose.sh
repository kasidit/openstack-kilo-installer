# Openstack icehouse installation script on ubuntu 14.04 
# by kasidit chanchio
# vasabilab, dept of computer science, 
# Thammasat University, Thailand
#
# Copyright 2014  Kasidit Chanchio
#
#!/bin/bash -x
#
case $1 in 
	0) sudo /bin/bash -x ./exe-stage00-SUDO-update.sh 2>&1 | tee log/s00.log; \
		printf "\nnext: ./exe-run-verbose.sh 2\n" ;;
	2) sudo ./exe-stage02-SUDO-network-preinstall.sh | tee log/s02.log ; \
		printf "\nnext on compute: cd OPSInstaller/compute ; ./exe-run-verbose.sh 0\n" ;;
	5) sudo /bin/bash -x ./exe-stage05-SUDO-network-mysql.sh 2>&1 | tee log/s05.log ; \
		printf "\nnext on compute: cd OPSInstaller/compute ; ./exe-run-verbose.sh 6\n"  ;;
	25) sudo /bin/bash -x ./exe-stage25-SUDO-network-neutron.sh 2>&1 | tee log/s25.log ; \
		printf "\nnext on controller:  cd OPSInstaller/controller ;./exe-run-verbose.sh 26\n"  ;;
	27) sudo /bin/bash -x ./exe-stage27-SUDO-ovs-service.sh 2>&1 | tee log/s27.log ; \
		printf "\nnext on controller: cd OPSInstaller/controller; ./exe-run-verbose.sh 28\n"  ;;
	*) printf "\ninvalid parameter value!\n" ;;
esac
