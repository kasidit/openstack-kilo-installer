cp /etc/sudoers /tmp/sudoers.save
echo "vasabi-1234loginname4321-ibasav ALL=NOPASSWD: ALL" >> /etc/sudoers

