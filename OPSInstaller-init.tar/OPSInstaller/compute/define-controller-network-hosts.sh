#!/bin/bash -x
#
# Openstack icehouse installation script on ubuntu 14.04
# by kasidit chanchio
# vasabilab, dept of computer science,
# Thammasat University, Thailand
#
# Copyright 2014  Kasidit Chanchio
#
#
# run below before launch this script
#printf "\nyou are supposed to be running ssh-agent at this point.\n"
# --->ssh-agent /bin/bash
# --> ssh-add
# copy Installer

cd $HOME/OPSInstaller-${1}/compute-${1}
pwd
cp /etc/hosts files/hosts.before_add_compute
#
echo "${1} ${2}.vasabi-1234domainname4321-ibasav ${2}" >> files/hosts.minimal
echo "${3} controller" >> files/hosts.minimal
echo "${4} network" >> files/hosts.minimal
cp files/hosts.minimal files/hosts
