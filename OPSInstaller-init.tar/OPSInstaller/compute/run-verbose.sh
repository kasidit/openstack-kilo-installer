# Openstack icehouse installation script on ubuntu 14.04 
# by kasidit chanchio
# vasabilab, dept of computer science, 
# Thammasat University, Thailand
#
# Copyright 2014  Kasidit Chanchio
#
#!/bin/bash -x
#
case $1 in 
	0) sudo /bin/bash -x ./stage00-SUDO-update.sh 2>&1 | tee log/s00.log; \
		printf "\nnext: ./run-verbose.sh 3\n" ;;
	3) sudo ./stage03-SUDO-compute-preinstall.sh | tee log/s03.log ; \
		printf "\nnext on controller: cd OPSInstaller/controller; ./run-verbose.sh 4\n" ;;
	6) sudo /bin/bash -x ./stage06-SUDO-compute-mysql.sh 2>&1 | tee log/s06.log ; \
		printf "\nnext on controller: cd OPSInstaller/controller; ./run-verbose.sh 7\n"  ;;
	19) sudo /bin/bash -x ./stage19-SUDO-nova-compute.sh 2>&1 | tee log/s19.log ; \
		printf "\nnext on controller: cd OPSInstaller/controller; ./run-verbose.sh 20\n"  ;;
	29) sudo /bin/bash -x ./stage29-SUDO-compute-neutron.sh 2>&1 | tee log/s29.log ; \
		printf "\nnext on controller: cd OPSInstaller/controller; ./run-verbose.sh 30\n"  ;;
	*) printf "\ninvalid parameter value!\n" ;;
esac
