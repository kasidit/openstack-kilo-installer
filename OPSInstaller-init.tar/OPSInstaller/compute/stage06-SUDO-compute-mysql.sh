# Openstack icehouse installation script 
# on ubuntu 14.04 by kasidit chanchio
# vasabilab, dept of computer science, Thammasat University, Thailand
# copyright 2014 
#
# run with sudo or as root.
#
#!/bin/bash -x
cd $HOME/OPSInstaller/compute
pwd
#
printf "Check ntp\n"
ntpq -c peers
ntpq -c assoc
#
printf "\nNext... \n\n"
read varkey

printf "1. set python mysqldb\n"
apt-get -y install python-mysqldb
